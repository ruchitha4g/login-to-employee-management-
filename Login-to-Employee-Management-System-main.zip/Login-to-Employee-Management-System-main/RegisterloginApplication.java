package com.Registerlogin.Registerlogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegisterloginApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegisterloginApplication.class, args);
	}

}
