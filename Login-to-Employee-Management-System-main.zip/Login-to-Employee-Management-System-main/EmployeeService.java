package com.Registerlogin.Registerlogin.Service;

import com.Registerlogin.Registerlogin.Dto.EmployeeDTO;

public interface EmployeeService {
    String addEmployee(EmployeeDTO employeeDTO);
}
